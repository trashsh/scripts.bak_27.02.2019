#!/usr/bin/bash

SCRIPT_PATH=$( dirname "${BASH_SOURCE[0]}" )

source $SCRIPT_PATH/highlight.sh
source $SCRIPT_PATH/json_log_beauty.sh
